// my public & private key
export const publickey = 'c42d3af813d44785fa4dc05a892653b7';
export const privatekey = 'a6b107623cfa6bad43a4a6fa629c5ee93ff6896e';